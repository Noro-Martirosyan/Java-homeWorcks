public class Xndir51_60 {
    public static void main(String[] args) {
        double a = 123;
        double miavor = a % 10;
        double tasnavor = (a % 100 - miavor) / 10;
        double harur = (a - a % 100) / 100;
        ///51
        boolean t = miavor == tasnavor + harur ? true : false;
        System.out.println("xndir 51: " + t);
        ///52
        boolean c = miavor == tasnavor || tasnavor == harur || miavor == harur ? true : false;
        System.out.println("xndir 52 " + c);
        ////53
        int k = 356;
        double res = a > k ? a / (miavor + tasnavor + harur) : miavor / a;
        System.out.println("xndir 53 " + res);
        ///54
        if (miavor > tasnavor && miavor > harur) {
            System.out.println(miavor);
        } else if (tasnavor > miavor && tasnavor > harur) {
            System.out.println(tasnavor);
        } else {
            System.out.println(harur);
        }

        //55
        if (miavor < tasnavor && miavor < harur) {
            System.out.println(miavor);
        } else if (tasnavor < miavor && tasnavor < harur) {
            System.out.println(tasnavor);
        } else {
            System.out.println(harur);
        }
    }
}

