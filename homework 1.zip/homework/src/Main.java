import java.awt.color.ICC_ColorSpace;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // shabatva orer
//        int  day = 3;
//        switch (day){
//            case 1:
//                System.out.println("dasi enq");
//                break;
//            case 2:
//                System.out.println("azat or");
//                break;
//            case 3:
//                System.out.println("dasi enq");
//                break;
//           case 4:
//               System.out.println("azat or");
//                break;
//           case 5:
//                System.out.println("dasi enq");
//                break;
//            case 6:
//                System.out.println("hangstyan or");
//                break;
//            case 7:
//                System.out.println("voch ashxatanqayin");
//                break;



   // xndragirq

   // xndir 31
//
//    int a = 120;
//    int b = 140;
//    int c = 160;
//    int d = 180;
//    if (a>b && a>c && a>d){
//        System.out.println(a);
//    }else if (b>a && b>c && b>d){
//        System.out.println(b);
//    }else if( c>a&& c>b&&c>d){
//        System.out.println(c);
//    }else {
//        System.out.println(d);
//    }





    // xndir 32



//    int a = 122;
//    int b = 144;
//    int c = 155;
//    int d = 166;
//    if ( a<b&& a<c&& a<d){
//        System.out.println(a);
//    }else if  (b<a&&b<c&&b<d){
//        System.out.println(b);
//    }else if (c<a&&c<b&&c<d)
//        System.out.println(c);
//    else{
//        System.out.println(d);
//    }


        // xndir 33



//       int a = 1;
//       int b = 2 ;
//       int c = 100;
//       int d = 50;
//       if ( a==1 || b==1 ||  c==1 || d==1){
//           System.out.println(true);
//       }else {
//           System.out.println(false);
//       }





        // xndir 34


//        int a = 10;
//        int b = 20;
//        int c = 30;
//        int d = 40;
//        if ( a+b== d+c || a+d==b+c || a+c == b+d ) {
//            System.out.println(true);
//            else {
//                System.out.println(false);
//            }


    // xndir 35

//    int a = 15;
//    int b = 25;
//    int c = 35;
//    int d = 45;
//    if(a==b+c+d  || b==a+b+b || c==a+b+d ||d==a+b+d){
//        System.out.println(true);
//    }else {
//        System.out.println(false);
//    }



    // xndir 36

//    float a = 11;
//    float b = 15;
//    float c = 18;
//    float d = 25;
//    if(a%2!=0 && b%2!=0 || a%2!=0 && c%2!=0 || a%2!=0 && d%2!=0|| d%2!=0 && b%2!=0 ||b%2!=0 && c%2!=0 || c%2!=0 &&
//    d%2!=0) {
//        System.out.println("1");
//    }else {
//        System.out.println("2");
//   }


     // xndir 37 kisat


//     int a = 10;    // abcd abdc acbd acdb adbc adcb
//     int b = 20;    // bacd badc bcda bcad bdac bdca
//     int c = 30;    // cabd cadb cbda cbad cdab cdba
//     int d = 40;    // dabc dacb dbca dbac dcab dcba
//     if (b-a==c-b==d-c || b-a==d-b==c-d || c-a==b-c==d-b || c-a==d-c==b-d || d-a==b-d==c-b || d-a==c-d==b-c||
//    a-b==c-a==d-c || a-b==d-a==c-d|| c-b==d-c==a-d||c-b==a-c==d-a||d-b==a-d==c-a || d-b==c-d==a-c){
//         System.out.println(true);
//
//     }else {
//         System.out.println(false);
//     }



        // xndir 39


//    int a = 22;
//    int b = 34;
//    int c = 48;
//    int d = 52;
//    if (a<b && a<c && a<d){
//        if(b<c){
//            if (c<d){
//                System.out.println(a+" "+b+" "+c+" "+d);
//            }
//        }
//    } else if(b<a && b<c && b<d){
//        if(a<c){
//            if(c<d){
//                System.out.println(b+" "+a+" "+c+" "+d);
//            }
//        }
//    }else if (c<a && c<b && c<d){
//        if(a<b){
//            if(b<d){
//                System.out.println(c+" "+a+" "+b+" "+d);
//            }
//        }
//    }else if(d<a && d<b && d<c){
//        if(a<b){
//            if(b<c){
//                System.out.println(d+" "+a+" "+b+" "+c);
//            }
//        }
//    }



     //xndir 40



    int  a = 15;
    int b = 23;
    int c = 35;
    int d = 44;
    if (a>b&& a>c && a>d){
        if(b>c){
            if(c>d){
                System.out.println(a+" "+b+" "+c+" "+d);
            }
        }
    }else if(b>a && b>c && b>d){
        if(a<c){
            if(c>d){
                System.out.println(b+" "+a+" "+c+" "+d);
            }
        }
    }else if (c>a && c>b && c>d){
        if(a>b){
            if(b>d){
                System.out.println(c+" "+a+" "+b+" "+d);
            }
        }
    }else if (d>a && d>b && d>c){
        if(a>b){
            if(b>c){
                System.out.println(d+" "+a+" "+b+" "+c);
            }
        }
    }


       }
    }



